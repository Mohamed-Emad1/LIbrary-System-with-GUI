package org.example;

public interface User2 {

        String getSearchKey();
        String lineRepresentation();
}
